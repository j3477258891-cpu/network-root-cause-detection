# V25 Semantic Residual Router

V25 keeps the verified `0.906324` submission as an immutable baseline. A
Qwen2.5-7B semantic expert and a fold-honest retrieval expert propose changes;
an action router decides whether an order should stay unchanged or receive up
to two additions, removals, or swaps. Exact dynamic programming preserves the
global prediction count.

No submission is written unless the final three-seed gate passes. The target is
`2951` OOF TP at exactly `3169` predictions, corresponding to the requested
online target of approximately `995` TP / `0.946324` at 1059 predictions.

## Local preparation

```powershell
python prepare_dataset.py `
  --root D:\zgyidong `
  --v24-data D:\zgyidong\experiments\v24_full_hetero\cloud_dataset `
  --output D:\zgyidong\experiments\v25_semantic_router\cloud_dataset

python build_packages.py `
  --data-root D:\zgyidong\experiments\v25_semantic_router\cloud_dataset `
  --output D:\zgyidong\experiments\v25_semantic_router\packages
```

The model weights are intentionally not copied into either archive. Upload a
local BF16 `Qwen2.5-7B-Instruct` directory separately. Install the wheels in
`requirements-cloud.txt` from an offline wheelhouse compatible with Python
3.10/aarch64.

## Ascend 910B probe

Use image `pytorch_v1.1:2.4.0-npu-py310-ubuntu22.04-aarch64`. Extract the code
and dataset archives, then run:

```bash
python run_probe.py \
  --data-root /root/data/v25 \
  --model /root/models/Qwen2.5-7B-Instruct \
  --locks /root/code/v11_constrained_report.json \
  --output /root/work/v25 \
  --device auto
```

The pipeline performs a real LoRA forward/backward memory check, unlabeled
domain adaptation, one seed of five honest folds, retrieval, the `+170 TP`
candidate oracle audit, action routing, and the `+100 TP` probe gate. Any failed
gate terminates with exit code 2 and `submission_generated: false`.

The lock report is not bundled because it is an input with test-specific
decisions. Upload
`D:\zgyidong\codexgz\v11\v11_constrained_report.json` beside the code archive.

## Full run

Only after the probe report says `gate_passed`:

```bash
python run_full.py \
  --data-root /root/data/v25 \
  --model /root/models/Qwen2.5-7B-Instruct \
  --locks /root/code/v11_constrained_report.json \
  --output /root/work/v25 \
  --submissions /root/work/submissions \
  --device auto
```

The final command trains all three seeds, intersects their action spaces,
averages action utilities, runs template/station/time stress tests, and calls
the guarded submission writer. Successful output includes the main CSV,
rank-only diagnostic CSV, action report, and SHA256.

## Important interpretation

The local perfect-expert integration smoke reaches an action-space oracle of
`+172 TP`, only two above the required `+170`. This validates the pipeline but
does not predict that a real Qwen fold will pass. The real cloud oracle report
is therefore a hard feasibility test and must not be bypassed or weakened.
