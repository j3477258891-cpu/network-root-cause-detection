# V24 Full Heterogeneous Graph Probe

V24 keeps every topology node and valid edge inside a disjoint graph per work
order. It does not merge repeated physical entity IDs across orders and does
not use raw RID, station name, IP, title, or location as device features.

The first cloud phase is deliberately bounded:

1. Run a worst-order full forward/backward memory smoke test.
2. Train seed `20260803` with five honest outer folds. An inner fold chooses
   the epoch count; the untouched outer fold is evaluated once after refit.
3. Stop unless fixed-K rank-only OOF is positive in at least three folds and
   the worst fold is at least `-2 TP`.
4. Never generate a submission during the probe phase.

Cloud command:

```bash
python run_probe.py \
  --data-root /path/to/v24_dataset \
  --output /root/work/v24_outputs \
  --device auto
```

The online champion remains the immutable `0.906324` file until a later full
three-seed gate passes. V19 full is rejected after the probe scored `0.905373`
(`-1 TP`).

